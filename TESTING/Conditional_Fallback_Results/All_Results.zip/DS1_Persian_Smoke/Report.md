# DS1_Persian_Smoke Conditional Fallback Retest

Recognizer: yolo. BASE, contrast, both, then eight rotations. Accepted BASE predictions and BASE multiple-letter rejections are preserved. Fallback predictions are flagged for review.

| Method | Accuracy | Macro precision | Macro recall | Macro F1 | Accepted-only correct |
|---|---:|---:|---:|---:|---:|
| BASE in this run | 47.98% | 91.52% | 47.98% | 61.58% | 89.71% |
| Conditional fallback | 63.03% | 83.32% | 63.03% | 69.41% | 75.25% |

Additional correct: 944. Additional wrong accepted: 955. Lost correct: 0.

Accuracy includes rejected images. These are image-level recognition scores, not bounding-box mAP. No training or threshold tuning was performed.
