# Conditional Fallback Retest

Prepared by Jeff Barrientos on 25 October 2026.

This package contains the completed local retest of all four datasets with the supplied YOLO checkpoint. The TESTING runner was updated; the browser scanner, scanner backend, and UI remain unchanged. No model weights or image datasets are included. The code changes have not been pushed.

## Read the results

Open Reports.docx for the interpretation and four dataset reports. Each dataset folder contains predictions.csv, metrics.csv, per_letter.csv, confusion_matrix.csv, report.json, and Report.md. The root comparison.csv compares BASE and fallback from the same run. negative_controls.csv reports the 64 blank and 64 two-letter synthetic validation controls. validation.json records the independent decision replay, metric checks, input identity checks, and document verification.

The new runner tries BASE, contrast, both contrast and eight rotations, then eight rotations alone. It only retries BASE no-detection and low-confidence outcomes. Accepted BASE answers and BASE multiple-letter rejections are preserved. The first stage with an accepted single-letter prediction wins. Within a rotation stage, the highest-confidence accepted view wins, with the lower angle breaking ties. If all stages fail, the BASE rejection is retained. The acceptance threshold remains 80%.

Recovered predictions have recovered=yes and needs_review=yes. These flags do not mean an answer is correct. They identify answers supplied by fallback for human review. The correct column uses the known reference label; rejections count as incorrect recognition. Negative controls have no letter reference, so their correct field is no even when properly rejected; use negative_controls.csv for rejection performance. Controls are excluded from the 32-class recognition metrics. Read BASE and fallback accuracy together with additional wrong accepts and accepted-only correctness. No threshold tuning or training occurred during this run.

## Run the program

Program/TESTING contains the updated standalone runner. Install its requirements using your Python interpreter, then run run_test.py or Run Test.cmd. Supply the separately held yolo11n.pt and select DS1_Persian, DS1_Persian_Smoke, DS2_Persian_Hand, and DS2_Persian_Hand_Smoke. Keep the Smoke wrapper metadata and folder structure intact. The required checkpoint SHA256 is 1b82317638d84627ee1ca455bad970ce70041d12194b0fb9c7762c1ba51540ab.

```powershell
python -m pip install -r requirements.txt
python run_test.py --model "C:\models\yolo11n.pt"
```

Run these commands inside Program/TESTING. If python is unavailable on PATH, use the full path to python.exe; the py launcher is not required. A CUDA-enabled PyTorch installation uses the NVIDIA GPU when available. Model files and source images are never overwritten. Results go to a new Runs folder unless --output is specified. Use --recognition base for the earlier detector-only workflow. Use --no-docx if Word report generation is not needed. Full repository validation controls are skipped with a message when the standalone package cannot find them.

## Sources and scope

Printed images: https://github.com/mehr32/Image-dataset-of-Persian-letters/tree/main

Handwritten images: https://github.com/myousefnezhad/persianhandwriting

The Smoke datasets are the full previously modified datasets, not small pilot sets. Their exact per-image rotation, flip, blur, and brightness/contrast parameters remain in the prediction CSVs. Test Set ReadMe.md gives the complete preparation and source details.

The fallback order was selected from earlier results on these same datasets. This local run verifies the implemented program and its tradeoffs; it is not independent handwriting validation or a measure of unseen-writer generalization. The batch runner uses the supplied YOLO detector alone and does not claim results for the scanner's additional crop classifier.
