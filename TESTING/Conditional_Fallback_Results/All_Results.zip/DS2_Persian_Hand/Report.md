# DS2_Persian_Hand Conditional Fallback Retest

Recognizer: yolo. BASE, contrast, both, then eight rotations. Accepted BASE predictions and BASE multiple-letter rejections are preserved. Fallback predictions are flagged for review.

| Method | Accuracy | Macro precision | Macro recall | Macro F1 | Accepted-only correct |
|---|---:|---:|---:|---:|---:|
| BASE in this run | 2.62% | 67.74% | 2.62% | 4.68% | 74.09% |
| Conditional fallback | 4.83% | 51.31% | 4.83% | 7.80% | 45.17% |

Additional correct: 709. Additional wrong accepted: 1,585. Lost correct: 0.

Accuracy includes rejected images. These are image-level recognition scores, not bounding-box mAP. No training or threshold tuning was performed.
