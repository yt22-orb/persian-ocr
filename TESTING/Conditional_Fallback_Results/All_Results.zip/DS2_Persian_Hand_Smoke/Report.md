# DS2_Persian_Hand_Smoke Conditional Fallback Retest

Recognizer: yolo. BASE, contrast, both, then eight rotations. Accepted BASE predictions and BASE multiple-letter rejections are preserved. Fallback predictions are flagged for review.

| Method | Accuracy | Macro precision | Macro recall | Macro F1 | Accepted-only correct |
|---|---:|---:|---:|---:|---:|
| BASE in this run | 4.62% | 82.52% | 4.62% | 8.24% | 72.86% |
| Conditional fallback | 13.28% | 70.48% | 13.28% | 18.97% | 45.13% |

Additional correct: 2,772. Additional wrong accepted: 4,617. Lost correct: 0.

Accuracy includes rejected images. These are image-level recognition scores, not bounding-box mAP. No training or threshold tuning was performed.
