# DS1_Persian Conditional Fallback Retest

Recognizer: yolo. BASE, contrast, both, then eight rotations. Accepted BASE predictions and BASE multiple-letter rejections are preserved. Fallback predictions are flagged for review.

| Method | Accuracy | Macro precision | Macro recall | Macro F1 | Accepted-only correct |
|---|---:|---:|---:|---:|---:|
| BASE in this run | 69.53% | 96.33% | 69.53% | 80.47% | 96.12% |
| Conditional fallback | 71.89% | 89.32% | 71.89% | 78.67% | 85.85% |

Additional correct: 148. Additional wrong accepted: 567. Lost correct: 0.

Accuracy includes rejected images. These are image-level recognition scores, not bounding-box mAP. No training or threshold tuning was performed.
